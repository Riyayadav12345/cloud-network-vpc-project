# Route Tables

## Public Route Table

Destination: 0.0.0.0/0
Target: Internet Gateway

## Private Route Table

Internal routing only
No direct internet access
