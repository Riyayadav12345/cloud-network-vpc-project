# Security Groups

## Public Server

Inbound:
- SSH (22)
- HTTP (80)
- HTTPS (443)

Outbound:
- All Traffic

## Private Server

Inbound:
- Application Traffic
- Database Traffic

Outbound:
- Restricted Internet Access
