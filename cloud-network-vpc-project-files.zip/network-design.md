# Network Design

## VPC
CIDR: 10.0.0.0/16

## Public Subnet
10.0.1.0/24

## Private Subnet
10.0.2.0/24

## Components
- Internet Gateway
- Route Tables
- Security Groups
- EC2 Instances

## Availability
Multi-tier architecture with isolated private resources.
