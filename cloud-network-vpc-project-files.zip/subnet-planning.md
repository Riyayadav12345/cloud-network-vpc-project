# Subnet Planning

| Subnet | CIDR |
|----------|----------|
| Public Subnet | 10.0.1.0/24 |
| Private Subnet | 10.0.2.0/24 |

Benefits:
- Security
- Scalability
- Isolation
